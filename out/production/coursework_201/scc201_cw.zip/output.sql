CREATE TABLE planets (
  popvalue INTEGER,
  planet_id INTEGER,
  name VARCHAR(15) NOT NULL,
 PRIMARY KEY (planet_id)
);

CREATE TABLE heroes (
  secretIdentity VARCHAR(30),
  codename VARCHAR(30),
  hero_id INTEGER,
  homeWorld_id INTEGER,
 PRIMARY KEY (hero_id),
 FOREIGN KEY (homeWorld_id) REFERENCES planets(planet_id)
);

CREATE TABLE powers (
  description VARCHAR (100),
  hero_id INTEGER,
 PRIMARY KEY (description, hero_id),
 FOREIGN KEY (hero_id) REFERENCES heroes(hero_id)
);

CREATE TABLE missions (
  name VARCHAR (100),
  planet_name VARCHAR (15) NOT NULL,
 PRIMARY KEY (name),
 FOREIGN KEY (planet_name) REFERENCES planets(name)
);

INSERT INTO planets VALUES (17, 1, "Antares");
INSERT INTO planets VALUES (8, 2, "Bgztl");
INSERT INTO planets VALUES (27, 3, "Bismoll");
INSERT INTO planets VALUES (8, 4, "Braal");
INSERT INTO planets VALUES (20, 5, "Cargg");
INSERT INTO planets VALUES (30, 6, "Colu");
INSERT INTO planets VALUES (30, 7, "Daxam");
INSERT INTO planets VALUES (0, 8, "Dryad");
INSERT INTO planets VALUES (10, 9, "Durla");
INSERT INTO planets VALUES (0, 10, "Earth");
INSERT INTO planets VALUES (0, 11, "Hyrakius");
INSERT INTO planets VALUES (27, 12, "Imsk");
INSERT INTO planets VALUES (0, 13, "Krypton");
INSERT INTO planets VALUES (27, 14, "Naltor");
INSERT INTO planets VALUES (8, 15, "Orando");
INSERT INTO planets VALUES (0, 16, "Phlon");
INSERT INTO planets VALUES (30, 17, "Rimbor");
INSERT INTO planets VALUES (27, 18, "Starhaven");
INSERT INTO planets VALUES (27, 19, "Talok VIII");
INSERT INTO planets VALUES (0, 20, "Teall");
INSERT INTO planets VALUES (27, 21, "Tharr");
INSERT INTO planets VALUES (0, 22, "Titan");
INSERT INTO planets VALUES (27, 23, "Trom");
INSERT INTO planets VALUES (8, 24, "Winath");
INSERT INTO planets VALUES (0, 25, "Xanthu");
INSERT INTO planets VALUES (34, 26, "Zoon");


INSERT INTO heroes VALUES ("Rokk Krinn ", "Cosmic Boy", 1, 4);
INSERT INTO heroes VALUES ("Garth Ranzz ", "Lightning Lad ", 2, 24);
INSERT INTO heroes VALUES ("Imra Ardeen ", "Saturn Girl ", 3, 22);
INSERT INTO heroes VALUES ("Luornu Durgo ", "Triplicate Girl", 4, 5);
INSERT INTO heroes VALUES ("Tinya Wazzo ", "Phantom Girl", 5, 2);
INSERT INTO heroes VALUES ("Kal-El (a.k.a. Clark Kent) ", "Superboy", 6, 13);
INSERT INTO heroes VALUES ("Reep Daggle ", "Chameleon Boy", 7, 9);
INSERT INTO heroes VALUES ("Gim Allon ", "Colossal Boy ", 8, 10);
INSERT INTO heroes VALUES ("Lyle Norg ", "Invisible Kid ", 9, 10);
INSERT INTO heroes VALUES ("Thom Kallor ", "Star Boy ", 10, 25);
INSERT INTO heroes VALUES ("James Cullen ", "Kid Quantum ", 11, 1);
INSERT INTO heroes VALUES ("Querl Dox ", "Brainiac 5", 12, 6);
INSERT INTO heroes VALUES ("Kara Zor-El", "Supergirl ", 13, 13);
INSERT INTO heroes VALUES ("", "Laurel Gand ", 14, 7);
INSERT INTO heroes VALUES ("Dirk Morgna ", "Sun Boy ", 15, 10);
INSERT INTO heroes VALUES ("Salu Digby ", "Shrinking Violet", 16, 12);
INSERT INTO heroes VALUES ("Chuck Taine ", "Bouncing Boy ", 17, 10);
INSERT INTO heroes VALUES ("Jo Nah ", "Ultra Boy", 18, 17);
INSERT INTO heroes VALUES ("Lar Gand ", "Mon-El", 19, 7);
INSERT INTO heroes VALUES ("Tenzil Kem ", "Matter-Eater Lad ", 20, 3);
INSERT INTO heroes VALUES ("Jan Arrah ", "Element Lad", 21, 21);
INSERT INTO heroes VALUES ("Ayla Ranzz ", "Lightning Lass", 22, 24);
INSERT INTO heroes VALUES ("Nura Nal ", "Dream Girl ", 23, 14);
INSERT INTO heroes VALUES ("Andrew Nolan ", "Ferro Lad ", 24, 10);
INSERT INTO heroes VALUES ("Val Armorr ", "Karate Kid ", 25, 10);
INSERT INTO heroes VALUES ("Projectra Wind'zzor ", "Princess Projectra", 26, 15);
INSERT INTO heroes VALUES ("Tasmia Mallor ", "Shadow Lass ", 27, 19);
INSERT INTO heroes VALUES ("Condo Arlik ", "Chemical King ", 28, 16);
INSERT INTO heroes VALUES ("Brin Londo ", "Timber Wolf", 29, 26);
INSERT INTO heroes VALUES ("Drake Burroughs ", "Wildfire", 30, 10);
INSERT INTO heroes VALUES ("Troy Stewart ", "Tyroc ", 31, 10);
INSERT INTO heroes VALUES ("", "Dawnstar", 32, 18);
INSERT INTO heroes VALUES ("", "Blok ", 33, 8);
INSERT INTO heroes VALUES ("Jacques Foccart ", "Invisible Kid II ", 34, 10);
INSERT INTO heroes VALUES ("Mysa Nal ", "White Witch", 35, 14);
INSERT INTO heroes VALUES ("Pol Krinn ", "Magnetic Kid ", 36, 4);
INSERT INTO heroes VALUES ("Brek Bannin ", "Polar Boy ", 37, 21);
INSERT INTO heroes VALUES ("(an unpronounceable glyph) ", "Quislet ", 38, 20);
INSERT INTO heroes VALUES ("Ganglios ", "Tellus ", 39, 11);
INSERT INTO heroes VALUES ("Nobody", "Hero on non-existant planet", 40, 473);


INSERT INTO powers VALUES ("Magnetism manipulation", 1);
INSERT INTO powers VALUES ("control and generation of magnetic fields", 1);
INSERT INTO powers VALUES ("Electrical manipulation", 2);
INSERT INTO powers VALUES ("control and generation of electrical fields", 2);
INSERT INTO powers VALUES ("Telepathy", 3);
INSERT INTO powers VALUES ("ability to read and control minds", 3);
INSERT INTO powers VALUES ("Ability to split into three bodies", 4);
INSERT INTO powers VALUES ("Intangibility", 5);
INSERT INTO powers VALUES ("Flight", 6);
INSERT INTO powers VALUES ("Invulnerability", 6);
INSERT INTO powers VALUES ("Superhuman Strength", 6);
INSERT INTO powers VALUES ("Superhuman Speed", 6);
INSERT INTO powers VALUES ("Super vision, consisting of", 6);
INSERT INTO powers VALUES ("X-Ray Vision", 6);
INSERT INTO powers VALUES ("Telescopic/Microscopic Vision", 6);
INSERT INTO powers VALUES ("Heat Vision", 6);
INSERT INTO powers VALUES ("Super-hearing", 6);
INSERT INTO powers VALUES ("Super Breath (including Freeze Breath)", 6);
INSERT INTO powers VALUES ("Eidetic memory", 6);
INSERT INTO powers VALUES ("Regeneration", 6);
INSERT INTO powers VALUES ("Longevity", 6);
INSERT INTO powers VALUES ("Other enhanced physical senses (including olfaction)", 6);
INSERT INTO powers VALUES ("Shapeshifting", 7);
INSERT INTO powers VALUES ("Ability to grow to gigantic size", 8);
INSERT INTO powers VALUES ("Invisibility to the naked eye", 9);
INSERT INTO powers VALUES ("Ability to increase the mass of objects", 10);
INSERT INTO powers VALUES ("Ability to cast stasis fields", 11);
INSERT INTO powers VALUES ("12th level intelligence", 12);
INSERT INTO powers VALUES ("Flight", 13);
INSERT INTO powers VALUES ("Invulnerability", 13);
INSERT INTO powers VALUES ("Superhuman Strength", 13);
INSERT INTO powers VALUES ("Superhuman Speed", 13);
INSERT INTO powers VALUES ("Super vision, consisting of", 13);
INSERT INTO powers VALUES ("X-Ray Vision", 13);
INSERT INTO powers VALUES ("Telescopic/Microscopic Vision", 13);
INSERT INTO powers VALUES ("Heat Vision", 13);
INSERT INTO powers VALUES ("Super-hearing", 13);
INSERT INTO powers VALUES ("Super Breath (including Freeze Breath)", 13);
INSERT INTO powers VALUES ("Eidetic memory", 13);
INSERT INTO powers VALUES ("Regeneration", 13);
INSERT INTO powers VALUES ("Longevity", 13);
INSERT INTO powers VALUES ("Other enhanced physical senses (including olfaction)", 13);
INSERT INTO powers VALUES ("Flight", 14);
INSERT INTO powers VALUES ("Invulnerability", 14);
INSERT INTO powers VALUES ("Superhuman Strength", 14);
INSERT INTO powers VALUES ("Superhuman Speed", 14);
INSERT INTO powers VALUES ("Super vision, consisting of", 14);
INSERT INTO powers VALUES ("X-Ray Vision", 14);
INSERT INTO powers VALUES ("Telescopic/Microscopic Vision", 14);
INSERT INTO powers VALUES ("Heat Vision", 14);
INSERT INTO powers VALUES ("Super-hearing", 14);
INSERT INTO powers VALUES ("Super Breath (including Freeze Breath)", 14);
INSERT INTO powers VALUES ("Eidetic memory", 14);
INSERT INTO powers VALUES ("Regeneration", 14);
INSERT INTO powers VALUES ("Longevity", 14);
INSERT INTO powers VALUES ("Other enhanced physical senses (including olfaction)", 14);
INSERT INTO powers VALUES ("light generation", 15);
INSERT INTO powers VALUES ("Heat generation", 15);
INSERT INTO powers VALUES ("Ability to shrink to microscopic size", 16);
INSERT INTO powers VALUES ("Super-bouncing", 17);
INSERT INTO powers VALUES ("Super-strength", 18);
INSERT INTO powers VALUES ("super-speed", 18);
INSERT INTO powers VALUES ("flight", 18);
INSERT INTO powers VALUES ("invulnerability", 18);
INSERT INTO powers VALUES ("flash vision", 18);
INSERT INTO powers VALUES ("penetra-vision", 18);
INSERT INTO powers VALUES ("Flight", 19);
INSERT INTO powers VALUES ("Invulnerability", 19);
INSERT INTO powers VALUES ("Superhuman Strength", 19);
INSERT INTO powers VALUES ("Superhuman Speed", 19);
INSERT INTO powers VALUES ("Super vision, consisting of", 19);
INSERT INTO powers VALUES ("X-Ray Vision", 19);
INSERT INTO powers VALUES ("Telescopic/Microscopic Vision", 19);
INSERT INTO powers VALUES ("Heat Vision", 19);
INSERT INTO powers VALUES ("Super-hearing", 19);
INSERT INTO powers VALUES ("Super Breath (including Freeze Breath)", 19);
INSERT INTO powers VALUES ("Eidetic memory", 19);
INSERT INTO powers VALUES ("Regeneration", 19);
INSERT INTO powers VALUES ("Longevity", 19);
INSERT INTO powers VALUES ("Other enhanced physical senses (including olfaction)", 19);
INSERT INTO powers VALUES ("Can eat any substance", 20);
INSERT INTO powers VALUES ("Elemental transmutation", 21);
INSERT INTO powers VALUES ("Electrical manipulation", 22);
INSERT INTO powers VALUES ("control and generation of electrical fields", 22);
INSERT INTO powers VALUES ("Precognition", 23);
INSERT INTO powers VALUES ("Ability to transform into iron", 24);
INSERT INTO powers VALUES ("superhuman strength", 24);
INSERT INTO powers VALUES ("invulnerability", 24);
INSERT INTO powers VALUES ("Mastery of all known martial arts", 25);
INSERT INTO powers VALUES ("Generation of illusions", 26);
INSERT INTO powers VALUES ("Shadow-casting", 27);
INSERT INTO powers VALUES ("Control over the rate of chemical reactions", 28);
INSERT INTO powers VALUES ("Superhuman agility", 29);
INSERT INTO powers VALUES ("Superhuman strength", 29);
INSERT INTO powers VALUES ("Energy blasts", 30);
INSERT INTO powers VALUES ("Energy manipulation", 30);
INSERT INTO powers VALUES ("flight.", 30);
INSERT INTO powers VALUES ("Sonic power that creates unusual effects", 31);
INSERT INTO powers VALUES ("Interstellar tracking", 32);
INSERT INTO powers VALUES ("unaided space travel", 32);
INSERT INTO powers VALUES ("flight", 32);
INSERT INTO powers VALUES ("Superhuman strength", 33);
INSERT INTO powers VALUES ("Superhuman physical resistance", 33);
INSERT INTO powers VALUES ("deliberately wrong", 500);
INSERT INTO powers VALUES ("energy absorption", 33);
INSERT INTO powers VALUES ("Invisibility to the naked eye and to most forms of detection", 34);
INSERT INTO powers VALUES ("Spellcasting", 35);
INSERT INTO powers VALUES ("Magnetism manipulation", 36);
INSERT INTO powers VALUES ("ability to generate and control magnetic fields", 36);
INSERT INTO powers VALUES ("Cold manipulation", 37);
INSERT INTO powers VALUES ("ability to absorb heat and produce cold", 37);
INSERT INTO powers VALUES ("Telepathy", 39);
INSERT INTO powers VALUES ("telekinesis", 39);


INSERT INTO missions VALUES ("Darkseid", "Apocalypse");
INSERT INTO missions VALUES ("Earth War", "Earth");
INSERT INTO missions VALUES ("Planet Kidnap", "Daxam");
INSERT INTO missions VALUES ("Mission on non-existant planet", "Zorgorn");


